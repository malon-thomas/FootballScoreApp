package com.example.android.footballscore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    //Tracks the score for Colts
    int scoreColts =0;

    //Tracks the score for Chiefs
    int scoreChiefs =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayForColts(0);
    }

    /**
     * Increase the score for Colts by 1 point.
     */
    public void addOneForColts(View v) {
        scoreColts = scoreColts +1;
        displayForColts(scoreColts);
    }

    /**
     * Increase the score for Colts by 2 point.
     */
    public void addTwoForColts(View v) {
        scoreColts = scoreColts +2;
        displayForColts(scoreColts);
    }



    /**
     * Increase the score for Colts by 3 points.
     */
    public void addThreeForColts(View v) {
        scoreColts = scoreColts +3;
        displayForColts(scoreColts);
    }

    /**
     * Increase the score for Colts by 7 points.
     */
    public void addSevenForColts(View v) {
        scoreColts = scoreColts +7;
        displayForColts(scoreColts);
    }

    /**
     * Displays the given score for Colts.
     */
    public void displayForColts(int score) {
        TextView scoreView = (TextView) findViewById(R.id.colts_score);
        scoreView.setText(String.valueOf(score));
    }

    public void resetScore(View v) {
        scoreColts = 0;
        scoreChiefs = 0;
        displayForColts(scoreColts);
        displayForChiefs(scoreChiefs);
    }

    /**
     * Displays the given score for Chiefs.
     */
    public void displayForChiefs(int score) {
        TextView scoreView = (TextView) findViewById(R.id.chiefs_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Increase the score for Chiefs by 1 points.
     */
    public void addOneForChiefs(View v) {
        scoreChiefs = scoreChiefs +1;
        displayForChiefs(scoreChiefs);
    }


    /**
     * Increase the score for Colts by 2 point.
     */
    public void addTwoForChiefs(View v) {
        scoreChiefs = scoreChiefs +2;
        displayForChiefs(scoreChiefs);
    }


    /**
     * Increase the score for Chiefs by 3 points.
     */
    public void addThreeForChiefs(View v) {
        scoreChiefs = scoreChiefs +3;
        displayForChiefs(scoreChiefs);
    }

    /**
     * Increase the score for Chiefs by 7 point.
     */
    public void addSevenForChiefs(View v) {
        scoreChiefs = scoreChiefs +7;
        displayForChiefs(scoreChiefs);
    }
}
